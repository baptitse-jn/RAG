# Agent RAG Web (Flask - Version Simplifiée)

Cette application web Flask implémente un agent conversationnel simple utilisant l'API Mistral pour répondre à des questions en se basant sur le contenu d'un fichier texte.

**NOTE IMPORTANTE :** Cette version a été simplifiée pour être compatible avec les environnements de déploiement serverless qui ne supportent pas les dépendances Python avec du code natif (comme `numpy`, `orjson`, `PyYAML`, souvent requis par des bibliothèques comme LangChain pour le RAG avancé). Elle n'utilise **pas** de vector store ni de mécanisme de recherche sémantique (RAG). À la place, elle envoie l'intégralité du contenu du fichier `src/data/documents.txt` comme contexte à chaque appel à l'API Mistral. Cette approche n'est pas évolutive pour de grands documents.

## Fonctionnalités

*   **Interface Web Simple :** Permet de poser des questions à l'agent via un navigateur.
*   **API Backend :** Endpoint `/ask` pour interroger l'agent.
*   **Logique Simplifiée :** Utilise le SDK Python officiel `mistralai` pour :
    *   Charger le contenu complet de `src/data/documents.txt`.
    *   Envoyer ce contenu et la question de l'utilisateur au modèle Mistral (`mistral-small-latest`).
    *   Afficher la réponse générée.

## Prérequis

*   Python 3.9+
*   Un compte Mistral AI et une clé API valide.

## Installation

1.  **Cloner ou télécharger le projet :**
    ```bash
    # Si vous avez reçu une archive .zip, décompressez-la.
    # Sinon, clonez le dépôt si disponible.
    ```

2.  **Créer et activer un environnement virtuel :**
    ```bash
    cd mon-agent-rag-web
    python -m venv venv
    source venv/bin/activate  # Sur Windows: venv\Scripts\activate
    ```

3.  **Installer les dépendances (minimales) :**
    ```bash
    pip install -r requirements.txt
    ```

## Configuration

1.  **Clé API Mistral :**
    *   Créez un fichier nommé `.env` à la racine du projet (`mon-agent-rag-web/.env`).
    *   Ajoutez la ligne suivante en remplaçant `VOTRE_CLE_API_MISTRAL_ICI` par votre clé API réelle :
        ```
MISTRAL_API_KEY=VOTRE_CLE_API_MISTRAL_ICI
        ```
    *   **IMPORTANT :** Sans une clé API valide, l'application ne pourra pas interroger le modèle Mistral et retournera une erreur.

2.  **(Optionnel) Source de données :**
    *   Le contenu utilisé comme contexte se trouve dans `src/data/documents.txt`. Vous pouvez modifier ce fichier.

## Lancement (Développement Local)

```bash
source venv/bin/activate
python src/main.py
```

L'application sera accessible sur `http://127.0.0.1:5000`.

## Déploiement Permanent

Cette application (version simplifiée) est prête pour un déploiement permanent via l'outil `deploy_apply_deployment` car elle n'utilise que des dépendances Python pures.

1.  **Assurez-vous que `requirements.txt` est à jour et ne contient que les dépendances nécessaires :**
    ```
    Flask>=3.0.0
    python-dotenv>=1.0.0
    mistralai>=1.7.0 # Ou la version compatible que vous avez installée
    httpx>=0.27.0
    ```
    (Exécutez `pip freeze > requirements.txt` si vous avez ajouté d'autres dépendances pures).

2.  **Vérifiez que le fichier `.env` n'est PAS inclus dans le déploiement.** Les secrets comme la clé API doivent être gérés via les variables d'environnement du service de déploiement.

3.  **Lancez le déploiement** (via l'interface de l'agent ou manuellement) en spécifiant le dossier racine du projet (`/home/ubuntu/mon-agent-rag-web`) et le type `flask`.

## Structure du Projet

```
mon-agent-rag-web/
├── venv/                   # Environnement virtuel Python
├── src/
│   ├── data/
│   │   └── documents.txt   # Source de données (contexte complet)
│   ├── static/
│   │   └── index.html      # Interface web
│   ├── __init__.py
│   ├── main.py             # Point d'entrée Flask, API
│   └── rag_logic.py        # Logique simplifiée (client mistralai direct)
├── .env                    # Fichier pour les secrets (NE PAS COMMIT/DEPLOYER)
└── requirements.txt        # Dépendances Python (pures)
```

## Limitations de cette version simplifiée

*   **Pas de RAG :** N'utilise pas de recherche vectorielle. L'intégralité du document est envoyée comme contexte.
*   **Non évolutif :** Ne convient pas aux documents volumineux en raison des limites de taille du contexte des modèles LLM.
*   **Coût potentiel :** Envoyer l'intégralité du contexte à chaque requête peut augmenter les coûts d'utilisation de l'API Mistral.

