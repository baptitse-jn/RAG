# -*- coding: utf-8 -*-
"""Logique simplifiée pour répondre aux questions en utilisant le client Mistral AI direct (v1.0+)."""

import os
from dotenv import load_dotenv
# Correction: Importer la nouvelle classe client
from mistralai import Mistral
# Pas besoin d'importer ChatMessage ou les nouvelles classes si on utilise des dicts

# Charger les variables d'environnement depuis .env
load_dotenv()

# --- Configuration --- #
MISTRAL_API_KEY = os.getenv("MISTRAL_API_KEY")
DATA_PATH = os.path.join(os.path.dirname(__file__), "data", "documents.txt")
MODEL_NAME = "mistral-small-latest" # Ou "mistral-large-latest", etc.

if not MISTRAL_API_KEY:
    raise ValueError("Clé API Mistral manquante. Définissez MISTRAL_API_KEY dans votre fichier .env")

# --- Initialisation du nouveau client Mistral --- #
print("Initialisation du nouveau client Mistral AI (v1.0+)...")
try:
    # Correction: Utiliser la classe Mistral
    client = Mistral(api_key=MISTRAL_API_KEY)
    print("Client Mistral AI initialisé.")
except Exception as e:
    print(f"Erreur lors de l'initialisation du client Mistral AI: {e}")
    client = None

# --- Chargement du Contexte Complet --- #
def load_full_context(file_path: str) -> str:
    """Charge le contenu brut d'un fichier texte."""
    print(f"Chargement du contexte complet depuis : {file_path}")
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            raw_text = f.read()
        if not raw_text or not raw_text.strip():
            print(f"Avertissement : Le fichier {file_path} est vide.")
            return ""
        print(f"Contexte chargé ({len(raw_text)} caractères).")
        return raw_text
    except FileNotFoundError:
        print(f"Erreur critique : Le fichier de données {file_path} n'a pas été trouvé.")
        return ""
    except Exception as e:
        print(f"Erreur lors du chargement du contexte depuis {file_path}: {e}")
        return ""

# Charger le contexte une seule fois au démarrage
full_context = load_full_context(DATA_PATH)

if not full_context:
    print("AVERTISSEMENT : Le contexte est vide. L'agent ne pourra pas répondre correctement.")

# --- Fonction pour interroger Mistral avec contexte (v1.0+) --- #
def ask_mistral_with_context(question: str) -> str:
    """Interroge le modèle Mistral en fournissant le contexte complet et la question."""
    if not client:
        return "Erreur: Le client Mistral AI n'a pas pu être initialisé."
    if not full_context:
        return "Erreur: Le contexte n'a pas pu être chargé."

    system_prompt = (
        "Tu es un assistant IA spécialisé dans la réponse aux questions basées sur un contexte fourni. "
        "Utilise uniquement les informations présentes dans le CONTEXTE ci-dessous pour répondre à la QUESTION. "
        "Ne cherche pas d'informations en dehors de ce contexte. "
        "Si le contexte ne contient pas la réponse à la question, indique-le clairement en disant : "
        "\'Désolé, le contexte fourni ne contient pas d\'informations permettant de répondre à cette question.\'\n\n"
        f"CONTEXTE COMPLET:\n{full_context}"
    )

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": f"QUESTION: {question}"}
    ]

    try:
        print(f"Envoi de la requête au modèle Mistral: {MODEL_NAME}")
        # Correction: Utiliser la méthode chat.complete
        chat_response = client.chat.complete(
            model=MODEL_NAME,
            messages=messages,
            temperature=0.7
        )
        
        if chat_response.choices and len(chat_response.choices) > 0:
            answer = chat_response.choices[0].message.content
            print("Réponse reçue de Mistral.")
            return answer
        else:
            print("Aucune réponse reçue de Mistral.")
            return "Erreur: Aucune réponse n'a été reçue du modèle Mistral."

    except Exception as e:
        print(f"Erreur lors de l'appel à l'API Mistral: {e}")
        if "401" in str(e) or "Unauthorized" in str(e):
             return "Erreur: Clé API Mistral invalide ou manquante."
        error_details = getattr(e, 'response', None)
        if error_details and hasattr(error_details, 'text'):
             return f"Erreur API Mistral: {error_details.text}"
        return f"Erreur lors de la communication avec l'API Mistral: {e}"


