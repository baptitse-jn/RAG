# -*- coding: utf-8 -*-
import sys
import os

# IMPORTANT: Add project root to sys.path
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, request, jsonify, render_template, send_from_directory
from dotenv import load_dotenv

# Import the SIMPLIFIED logic using mistralai client directly
try:
    from src.rag_logic import ask_mistral_with_context
except ImportError as e:
    print(f"Error importing simplified logic: {e}")
    # Define a dummy function if import fails
    def ask_mistral_with_context(question: str) -> str:
        print("WARNING: Simplified logic failed to import. Using dummy function.")
        return f"Dummy response for: {question}"
except Exception as e:
    # Catch potential errors during rag_logic.py initialization (like missing API key)
    print(f"CRITICAL ERROR during simplified logic import/initialization: {e}")
    def ask_mistral_with_context(question: str) -> str:
        return f"ERROR: Simplified logic failed to initialize ({e}). Dummy response for: {question}"

# Load environment variables from .env file
load_dotenv()

# Initialize Flask app
app = Flask(__name__, static_folder="static", template_folder="static")

# No pre-initialization needed here as rag_logic handles client init
print("Flask app initialized. Mistral client initialization is handled in rag_logic.")

@app.route("/")
def index():
    """Serve the main HTML page."""
    return render_template("index.html")

@app.route("/ask", methods=["POST"])
def ask_simplified():
    """API endpoint to ask a question using the simplified context approach."""
    if not request.is_json:
        return jsonify({"error": "Request must be JSON"}), 400

    data = request.get_json()
    question = data.get("question")

    if not question:
        return jsonify({"error": "Missing 'question' in request body"}), 400

    print(f"Received question: {question}")

    try:
        # Call the function directly from the imported module
        response = ask_mistral_with_context(question)
        print(f"Generated response: {response}")
        # Check if the response indicates an error from the logic function
        if response.startswith("Erreur:"):
             # Return a 500 error if the logic function reported an issue
             return jsonify({"error": response}), 500
        else:
            return jsonify({"answer": response})

    except Exception as e:
        # Catch unexpected errors during the request handling
        print(f"Unexpected error invoking simplified logic: {e}")
        error_message = f"An unexpected server error occurred: {str(e)}"
        return jsonify({"error": error_message}), 500

@app.route("/static/<path:filename>")
def serve_static(filename):
    return send_from_directory(app.static_folder, filename)

if __name__ == "__main__":
    # Use port 5000 for development, listen on 0.0.0.0
    app.run(host="0.0.0.0", port=5000, debug=True)

